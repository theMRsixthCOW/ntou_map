// Initialize Leaflet map
const map = L.map("map", {
    center: [25.14939, 121.77559],
    zoom: 17.6,
    zoomControl: false, // We will add custom zoom controls if needed
    attributionControl: false // Attribution will be handled by OSM Buildings
});

// Add OpenStreetMap tiles
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a> contributors"
}).addTo(map);

// Initialize OSM Buildings
const osmb = new OSMBuildings(map).load();

// Set initial tilt and rotation
osmb.setTilt(45);
osmb.setRotation(7);

// Global variables for building data and search
let buildingData = [];
let fromBuilding = null;
let toBuilding = null;
let polyline = null;
let infoBox = null;
let highlightedBuildingId = null;

// Function to load building data from data.json
async function loadBuildingData() {
    try {
        const response = await fetch("data.json");
        buildingData = await response.json();
        console.log("Building data loaded:", buildingData);
    } catch (error) {
        console.error("Error loading building data:", error);
        updateStatus("Error: Could not load building data.", true);
    }
}

// Function to update status message
function updateStatus(message, isError = false) {
    const statusElement = document.getElementById("status-message");
    statusElement.textContent = message;
    statusElement.style.color = isError ? "#ff0000" : "#00aaff";
}

// Call to load building data when the script starts
loadBuildingData();

// Implement building click interaction
osmb.on("click", function(e) {
    if (e.feature) {
        const clickedBuilding = buildingData.find(b => b.name === e.feature.properties.name || b.name_ch === e.feature.properties.name);
        if (clickedBuilding) {
            highlightBuilding(e.feature.id);
            showInfoBox(clickedBuilding, e.latlng);
            autoZoomToBuilding(e.latlng);
        }
    } else {
        hideInfoBox();
        osmb.highlight(null);
        highlightedBuildingId = null;
    }
});

function highlightBuilding(buildingId) {
    if (highlightedBuildingId) {
        osmb.highlight(highlightedBuildingId, null); // Remove previous highlight
    }
    osmb.highlight(buildingId, '#ffff00'); // Light yellow highlight
    highlightedBuildingId = buildingId;
}

function showInfoBox(building, latlng) {
    if (infoBox) {
        map.removeLayer(infoBox);
    }

    const content = `
        <div class="info-box">
            --------------------------------<br>
            BUILDING DATA<br>
            <br>
            NAME: ${building.name}<br>
            CHINESE: ${building.name_ch}<br>
            CODE: ${building.code_id}<br>
            LOCATION GRID: ${building.location_code}<br>
            --------------------------------
        </div>
    `;

    infoBox = L.popup({
        closeButton: false,
        autoClose: false,
        closeOnEscapeKey: false,
        closeOnClick: false,
        className: 'industrial-popup',
        offset: L.point(0, -20) // Offset to appear above the building
    })
    .setLatLng(latlng)
    .setContent(content)
    .openOn(map);

    // Adjust info box position to follow cursor (this is a simplified approach)
    map.on('mousemove', function(e) {
        if (infoBox && infoBox.isOpen()) {
            infoBox.setLatLng(e.latlng);
        }
    });
}

function hideInfoBox() {
    if (infoBox) {
        map.removeLayer(infoBox);
        infoBox = null;
    }
}

function autoZoomToBuilding(latlng) {
    map.flyTo(latlng, 18, {duration: 1.5}); // Smooth zoom to building
}

// Fuzzy matching function
function fuzzyMatch(searchTerm, building) {
    const lowerSearchTerm = searchTerm.toLowerCase();
    const fieldsToSearch = [
        building.name.toLowerCase(),
        building.name_ch,
        building.code_id.toLowerCase(),
        building.number.toLowerCase(),
        building.location_code.toLowerCase()
    ];

    // Prioritize exact match
    if (fieldsToSearch.includes(lowerSearchTerm)) {
        return { score: 100, building: building };
    }

    let maxScore = 0;
    for (const field of fieldsToSearch) {
        if (field.includes(lowerSearchTerm)) {
            // Simple scoring: longer matches, or matches at the beginning get higher scores
            const score = (lowerSearchTerm.length / field.length) * 50 + (field.indexOf(lowerSearchTerm) === 0 ? 30 : 0);
            if (score > maxScore) {
                maxScore = score;
            }
        }
    }
    return { score: maxScore, building: building };
}

function findBuilding(searchTerm) {
    if (!searchTerm) return null;

    const matches = buildingData
        .map(b => fuzzyMatch(searchTerm, b))
        .filter(m => m.score > 0)
        .sort((a, b) => b.score - a.score); // Sort by score descending

    return matches.length > 0 ? matches[0].building : null;
}

// Search functionality
const fromInput = document.getElementById("from-input");
const toInput = document.getElementById("to-input");
const navigateButton = document.getElementById("navigate-button");

navigateButton.addEventListener("click", async () => {
    const fromSearchTerm = fromInput.value;
    const toSearchTerm = toInput.value;

    updateStatus("Searching for locations...");

    fromBuilding = findBuilding(fromSearchTerm);
    toBuilding = findBuilding(toSearchTerm);

    if (fromBuilding && toBuilding) {
        if (fromBuilding.number === toBuilding.number) {
            updateStatus("Error: Start and end locations are the same.", true);
            if (polyline) {
                map.removeLayer(polyline);
                polyline = null;
            }
            return;
        }
        updateStatus("Locations found. Drawing path...");
        await drawNavigationLine(fromBuilding, toBuilding);
    } else {
        updateStatus("Error: One or both locations not found. Please try again.", true);
        if (polyline) {
            map.removeLayer(polyline);
            polyline = null;
        }
    }
});

async function drawNavigationLine(startBuilding, endBuilding) {
    // Remove existing line if any
    if (polyline) {
        map.removeLayer(polyline);
    }

    const startCoords = [startBuilding.lat, startBuilding.lon];
    const endCoords = [endBuilding.lat, endBuilding.lon];

    if (!startCoords[0] || !endCoords[0]) {
        updateStatus("Error: Missing coordinates for one or both buildings.", true);
        return;
    }

    polyline = L.polyline([startCoords, endCoords], {
        color: 'white',
        weight: 4,
        opacity: 1,
        dashArray: '10, 10' // For animated effect
    }).addTo(map);

    // Animate drawing effect
    const path = polyline._path;
    const length = path.getTotalLength();
    path.style.transition = path.style.WebkitTransition = 'none';
    path.style.strokeDasharray = length + ' ' + length;
    path.style.strokeDashoffset = length;
    path.getBoundingClientRect(); // Trigger a reflow, flushing the CSS changes
    path.style.transition = path.style.WebkitTransition = 'stroke-dashoffset 2s ease-in-out';
    path.style.strokeDashoffset = '0';

    updateStatus("Path drawn successfully.");
}

// Debounce function for search input
function debounce(func, delay) {
    let timeout;
    return function(...args) {
        const context = this;
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(context, args), delay);
    };
}

// Apply debounce to input fields (optional, but good for performance)
fromInput.addEventListener('input', debounce(() => {
    // Can add live search suggestions here if needed
}, 300));
toInput.addEventListener('input', debounce(() => {
    // Can add live search suggestions here if needed
}, 300));

// Initial status
updateStatus("SYSTEM ONLINE");
